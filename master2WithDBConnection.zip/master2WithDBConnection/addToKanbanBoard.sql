INSERT INTO kanbanboard (preproduction, production, closeout, archived)
VALUES ('Current Status','','','');