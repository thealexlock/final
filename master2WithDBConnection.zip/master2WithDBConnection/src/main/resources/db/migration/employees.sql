CREATE TABLE public.employees(
id SERIAL primary key NOT NULL ,
name varchar(24),
position varchar(24),
rate FLOAT,
date varchar(11)
);