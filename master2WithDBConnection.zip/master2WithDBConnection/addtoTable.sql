INSERT INTO customerprojects (customer_name,date,phone_number,street_address,city,state,zipcode,cost,description)
VALUES ('Vaqui', '12/02/2018', '14938532', '', '', '', '', '188.95', 'Bestie');